# SPAMwa

Sudah tidak bekerja scriptnya ..

- Youtube https://youtube.com/Din-zUgex95
